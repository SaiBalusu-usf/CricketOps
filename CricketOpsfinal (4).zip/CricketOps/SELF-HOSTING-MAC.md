# Self-Hosting on a Mac Studio with Tailscale

A permanent, cloud-free home for ICAT Cricket Live: the Docker stack runs
24/7 on a Mac Studio at home, and every operator device — scorer phone,
streamer phone, director phone, the OBS laptop at the ground — reaches it
over [Tailscale](https://tailscale.com), a free WireGuard mesh. Nothing is
rented, nothing is exposed on your router, and the server's address never
changes no matter which ground or hotspot you're on.

```
                        Tailscale (WireGuard mesh, free tier)
   scorer phone ────────────────┐
   streamer phone ──────────────┤
   OBS laptop (at ground) ──────┼────▶  Mac Studio (home, wired Ethernet)
   director phone ──────────────┘        └─ Docker: nginx + app + postgres
                                              https://<machine>.<tailnet>.ts.net
   spectators ──▶ YouTube stream (or Tailscale Funnel → /live, see §4)
```

What this buys you over the laptop-at-the-ground model:

- **One stable HTTPS address** (`https://<machine>.<tailnet>.ts.net`) with a
  real Let's Encrypt certificate — no local-CA install on any phone, and the
  camera (`getUserMedia`) HTTPS requirement is satisfied everywhere.
- **No router configuration.** Tailscale traverses NAT outbound; zero open
  ports on your home network.
- **Permanent archive.** Every match ever played lives in one Postgres
  volume with nightly backups, instead of scattered across laptops.

What it costs you: match day now depends on internet at the ground *and* at
home. §5 quantifies that and gives the fallback runbook.

---

## 1. Prepare the Mac Studio

```sh
xcode-select --install                 # git
brew install --cask docker             # Docker Desktop (Apple silicon build)
git clone https://github.com/SaiBalusu-usf/CricketOps.git
cd CricketOps
```

Open Docker Desktop once and let it start. Don't install Node, Postgres, or
ffmpeg on the Mac itself — everything runs in containers.

Find the Studio's home-LAN IP (usually the wired Ethernet port):

```sh
ipconfig getifaddr en0 || ipconfig getifaddr en1
```

Create `.env` (Tailscale values are filled in during §2):

```sh
cp .env.docker.example .env
```

```ini
LAN_IP=192.168.1.120                            # the Studio's home-LAN IP
PUBLIC_HTTP_ORIGIN=http://192.168.1.120:3333
PUBLIC_HTTPS_ORIGIN=https://192.168.1.120:3443  # replaced by ts.net name in §2
```

Start and verify:

```sh
docker compose up --build -d
docker compose --profile test run --build --rm test                      # engine tests
docker compose --profile test run --build --rm test npm run acceptance   # 13-step E2E
docker compose exec app npm run demo                                     # seed m-demo
```

Open <http://localhost:3333> and click through `/console/m-demo` and
`/live/m-demo`.

## 2. The Tailscale layer

Install and sign in (same account on the Studio and every operator device):

```sh
brew install --cask tailscale
```

In the [Tailscale admin console](https://login.tailscale.com/admin/dns),
enable **MagicDNS** and **HTTPS certificates**. Then, on the Studio:

```sh
tailscale serve --bg 3333
tailscale serve status        # shows the https://<machine>.<tailnet>.ts.net URL
```

`tailscale serve` publishes the app **to your tailnet only**, terminating
TLS with a real Let's Encrypt certificate for the machine's ts.net name and
proxying to the stack's HTTP port. WebSockets (Socket.IO) pass through, so
live updates work unchanged.

Point the app's QR codes and share links at the stable name — edit `.env`:

```ini
PUBLIC_HTTPS_ORIGIN=https://macstudio.tail803500.ts.net   # your name from `serve status`
```

then `docker compose down && docker compose up -d`.

Both doors stay open at once:

| Device | URL |
|---|---|
| Anything at home on the LAN | `http://192.168.1.120:3333` |
| Any tailnet device, anywhere | `https://<machine>.<tailnet>.ts.net` |

The ts.net URL is the one operators bookmark: it works from the ground, from
home, from a moving car. Because Tailscale terminates HTTPS with a publicly
trusted certificate, the phone-camera `/stream` surface works with **no CA
install** — skip that entire step from the LAN-only guide.

`TRUST_PROXY` is already enabled in `compose.yaml`, so rate limiting and
client-IP handling remain correct behind the proxy.

**Verify end-to-end:** from a phone on cellular (Wi-Fi off), open
`https://<machine>.<tailnet>.ts.net/live/m-demo`. If that loads, the whole
chain — Tailscale → serve → nginx → app → Postgres — is proven.

## 3. Make the Studio server-grade

A match must survive power blips, reboots, and nobody being home.

```sh
sudo pmset -a sleep 0 autorestart 1   # never sleep; power back on after an outage
```

- **Auto-login** (System Settings → Users & Groups): Docker Desktop is a
  user-session app — without auto-login, a reboot leaves the stack down
  until someone logs in. FileVault blocks auto-login; for a machine that
  never leaves the house, turning FileVault off is the usual trade.
- **Docker Desktop → Settings → General → "Start Docker Desktop when you
  sign in."** Every service in `compose.yaml` is `restart: unless-stopped`,
  so the chain is: power returns → Mac boots → auto-login → Docker starts →
  stack up. No hands.
- **DHCP reservation** for the Studio in your router, so the LAN half of
  `.env` never goes stale.
- **A small UPS** rides through the 30-second blips that would otherwise
  reboot the machine mid-match.
- **Tailscale reconnects at login** (it's a login item by default) — verify
  once with a test reboot: power-cycle the Mac and confirm the ts.net URL
  comes back on its own.

## 4. Who can reach what

1. **Operators** (scorer, streamer, director, OBS laptop): install Tailscale,
   sign in, use the ts.net URL. The free tier (3 users, 100 devices) covers a
   club's devices comfortably.
2. **Remote spectators**: the **YouTube stream is the public surface** — that
   is what this platform produces. Family watches YouTube, not `/live`.
3. **The public live scorecard** (optional): `tailscale funnel --bg 3333`
   makes the ts.net URL **publicly** reachable — still no cloud host, still
   no open router ports. Caveats:
   - Funnel exposes the *whole* app. PINs protect scoring/directing and the
     server rate-limits, but strangers could create junk matches from the
     landing page.
   - Funnel bandwidth is modest: fine for scorecards, never for video.

   Recommended posture: **Funnel off by default**; turn it on when someone
   asks for the live link on match day, and `tailscale funnel reset`
   afterwards.

At-ground spectators on the ground's own Wi-Fi can't see the Studio (they're
not on the tailnet) — point them at the YouTube stream, or enable Funnel.

## 5. Failure modes — what "real time" depends on

| Failure | Effect | Mitigation |
|---|---|---|
| Ground hotspot dies | The console keeps scoring **offline** (localStorage queue, flushes on reconnect). Overlays/live freeze until it's back. | Built-in offline queue; keep a second phone that can hotspot. |
| Home internet dies | Everything down. | Fallback runbook below. |
| Home power blip | Stack down until reboot completes. | UPS + §3 auto-restart chain. |
| Tailscale can't go direct (CGNAT both ends) | Traffic relays via DERP: +50–150 ms. Irrelevant for scoring/overlays, tolerable for video. | Nothing needed. |

**Bandwidth math for Tier-2 streaming** (phone → server ffmpeg → YouTube):
chunks travel phone → Studio → YouTube, so home upload carries the stream
twice-ish — ~2.5 Mbps in and ~3 Mbps out concurrently. You want **≥ 10 Mbps
home upload**. Tier 1 (phone camera into OBS at the ground over WebRTC) is
immune: media stays peer-to-peer on the ground LAN; only signaling touches
the Studio.

**Fallback runbook — practice once so it's boring:** the stack is fully
portable. Keep Docker + this repo on a laptop as a cold spare. If home is
unreachable on match day:

1. On the laptop at the ground: set `.env` to the laptop's hotspot IP,
   `docker compose up -d`, create the match there, score over the local
   hotspot exactly as in [HOSTING.md](HOSTING.md).
2. Afterwards, move the finished match to the Studio: download
   `http://localhost:3333/api/matches/<id>/export` from the laptop, then
   `curl -X POST -H 'Content-Type: application/json' --data @<file> https://<machine>.<tailnet>.ts.net/api/import`.

Zero data loss, ten-minute detour.

## 6. Backups

Nightly Postgres dump into a normal folder (which Time Machine then backs
up — don't rely on Time Machine to capture Docker's internal VM disk):

```sh
mkdir -p ~/CricketBackups
crontab -e
```

```cron
0 3 * * * cd $HOME/CricketOps && /usr/local/bin/docker compose exec -T postgres pg_dump -U icat icat_cricket | gzip > $HOME/CricketBackups/icat-$(date +\%F).sql.gz
```

Plus the built-in per-match archive: after each match, save
`/api/matches/<id>/export` — a single self-contained JSON that restores on
**any** instance via `POST /api/import`.

**Restore drill** (run it once now, not during a crisis):

```sh
gunzip -c ~/CricketBackups/icat-2026-07-01.sql.gz | \
  docker compose exec -T postgres psql -U icat icat_cricket
```

## 7. Maintenance routine

- **Update the app:**

  ```sh
  git pull && docker compose up --build -d
  docker compose --profile test run --build --rm test npm run acceptance
  ```

  Run the acceptance line before a match week, not the morning of.
- **macOS updates reboot the machine** — apply them the day *after* a match.
- **Match-day morning check (60 seconds):**
  1. `docker compose ps` — every service `Up`.
  2. Open the ts.net URL from a phone on cellular.
  3. `docker compose logs --since 24h app` — nothing loud.

## 8. Security posture

- **Zero open router ports** — Tailscale is outbound-only NAT traversal.
- Everything else ships in the app already: PIN auth with brute-force
  lockout, single-writer locks with clean takeover, write-only stream-key
  storage (never broadcast, exported, or logged), read-only overlays and
  live pages.
- The only new decision surface is **Funnel** (§4) — keep it off by default.
- Optional hardening: a tailnet ACL can restrict guest users to ports
  3333/3443, but with a handful of trusted operators the default policy is
  fine.

## Quick reference

```sh
tailscale serve --bg 3333        # publish to tailnet (HTTPS, LE cert)
tailscale serve status           # show the public name / current config
tailscale funnel --bg 3333       # expose publicly (match day only)
tailscale funnel reset           # …and back off
docker compose up -d             # start stack
docker compose down              # stop stack (data persists; NEVER add -v)
docker compose ps                # health at a glance
docker compose logs -f app       # live server logs
```
